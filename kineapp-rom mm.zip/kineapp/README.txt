KINEMOTION - ANALISIS DE MARCHA Y ROM

ARCHIVOS
- index.html: estructura de la interfaz.
- style.css: diseño visual responsive (escritorio, tablet y celular).
- index.js: webcam, carga de video, MediaPipe Pose y gráfico ROM.

COMO EJECUTAR
1. Descomprime el archivo ZIP.
2. Abre la carpeta en Visual Studio Code.
3. Inicia un servidor local. Por ejemplo, desde la terminal ejecuta:
   python -m http.server 8000
4. Abre en Chrome o Edge:
   http://localhost:8000
5. Pulsa "Iniciar webcam" y concede permiso, o usa "Cargar video".

IMPORTANTE
- Para acceder a la webcam, el navegador requiere HTTPS o localhost.
- La primera carga necesita conexión a Internet para descargar MediaPipe, Chart.js y las fuentes.
- Se recomienda una toma lateral, con rodilla, tobillo y pie visibles.
- El ángulo se estima en 2D mediante landmarks de rodilla, tobillo y pie. La convención de esta demo usa 0 grados como neutro y presenta valores positivos para dorsiflexión y negativos para flexión plantar.
- Los valores y rangos son orientativos; esta interfaz no está validada como dispositivo médico ni entrega diagnósticos.
